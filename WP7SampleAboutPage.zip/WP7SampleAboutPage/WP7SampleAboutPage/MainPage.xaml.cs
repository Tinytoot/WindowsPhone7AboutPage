﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Tasks;
using System.Reflection;

namespace WP7SampleAboutPage
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();

            // Set the data context of the listbox control to the sample data
            DataContext = App.ViewModel;
            this.Loaded += new RoutedEventHandler(MainPage_Loaded);
        }

        // Load data for the ViewModel Items
        private void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            if (!App.ViewModel.IsDataLoaded)
            {
                App.ViewModel.LoadData();
            }
        }

        #region AboutPageClickEvents

        private void Support_Click(object sender, RoutedEventArgs e)
        {
            var assembly = Assembly.GetExecutingAssembly().FullName;
            string version = assembly.Split('=')[1].Split(',')[0];

            EmailComposeTask emailcomposer = new EmailComposeTask();
            emailcomposer.To = "Your Email Address";
            emailcomposer.Subject = "Support Request from Your Application Title version " + version;
            emailcomposer.Body = "";
            emailcomposer.Show();
        }

        private void Review_Click(object sender, RoutedEventArgs e)
        {
            MarketplaceReviewTask marketplaceReviewTask = new MarketplaceReviewTask();
            marketplaceReviewTask.Show();
        }

        private void OtherApps_Click(object sender, RoutedEventArgs e)
        {
            MarketplaceSearchTask marketplaceSearchTask = new MarketplaceSearchTask();
            marketplaceSearchTask.SearchTerms = "Your Windows Phone Marketplace publishing name";
            marketplaceSearchTask.Show();
        }

        #endregion

    }
}